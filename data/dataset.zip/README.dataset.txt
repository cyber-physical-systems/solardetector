# solarFinder > 2022-08-08 2:07pm
https://universe.roboflow.com/object-detection/solarfinder

Provided by Roboflow
License: CC BY 4.0

